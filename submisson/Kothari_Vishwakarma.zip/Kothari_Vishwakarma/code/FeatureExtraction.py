
import CreateDataset

def main():
    CreateDataset.main()

if __name__ == '__main__':
    main()
